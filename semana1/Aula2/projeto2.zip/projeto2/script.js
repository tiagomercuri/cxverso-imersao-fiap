// 2. Closure (Fábrica de Carrinho)
function criarLojaDoces() {
    // Estado privado (encapsulado pelo closure)
    let itens = [];
    // Função interna para atualizar o HTML (DOM)
    const renderizar = () => {
        const tela = document.getElementById('carrinho');
        if (!tela)
            return;
        if (itens.length === 0) {
            tela.innerHTML = '<h3>Seu Carrinho está vazio 🛒</h3>';
            return;
        }
        const total = itens.reduce((soma, item) => soma + item.preco, 0);
        tela.innerHTML = `
            <h3>🍬 Resumo do Pedido</h3>
            <ul>
                ${itens.map(item => `
                    <li>
                        <span>${item.nome}</span>
                        <span>
                            R$ ${item.preco.toFixed(2)}
                            <button class="btn-remover" onclick="removerDoCarrinho(${item.id})">X</button>
                        </span>
                    </li>
                `).join('')}
            </ul>
            <hr>
            <p style="font-size: 1.2rem;"><strong>Total a pagar: R$ ${total.toFixed(2)}</strong></p>
        `;
    };
    // Retorno da Interface Pública (apenas estes métodos são acessíveis)
    return {
        adicionar: (produto) => {
            // Cria um ID único temporal para permitir adicionar o mesmo doce várias vezes
            itens = [...itens, { ...produto, id: Date.now() + Math.random() }];
            renderizar();
        },
        remover: (id) => {
            itens = itens.filter(item => item.id !== id);
            renderizar();
        },
        obterItens: () => [...itens], // Retorna uma cópia para proteger o original
        finalizarPedido: (callback) => {
            const total = itens.reduce((soma, item) => soma + item.preco, 0);
            callback(total, [...itens]);
        }
    };
}
// 3. Inicialização
const minhaDoceria = criarLojaDoces();
// 4. Captura de Eventos (DOM)
const botoes = document.querySelectorAll('.btn-comprar');
botoes.forEach(botao => {
    botao.addEventListener('click', (e) => {
        // Correção de tipagem para HTMLButtonElement
        const elemento = e.currentTarget;
        const id = Number(elemento.getAttribute('data-id'));
        const nome = elemento.getAttribute('data-nome') || '';
        const preco = Number(elemento.getAttribute('data-preco'));
        minhaDoceria.adicionar({ id, nome, preco });
    });
});
// 5. Exposição Global para o HTML (Necessário para o onclick="removerDoCarrinho" funcionar)
window.removerDoCarrinho = function (id) {
    minhaDoceria.remover(id);
};
export {};
